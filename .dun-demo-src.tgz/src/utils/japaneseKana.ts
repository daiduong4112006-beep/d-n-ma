// Japanese Romaji <-> Kana Engine & Utilities

const HIRAGANA_MAP: Record<string, string> = {
  a: 'あ', i: 'い', u: 'う', e: 'え', o: 'お',
  ka: 'か', ki: 'き', ku: 'く', ke: 'け', ko: 'こ',
  ga: 'が', gi: 'ぎ', gu: 'ぐ', ge: 'げ', go: 'ご',
  sa: 'さ', shi: 'し', si: 'し', su: 'す', se: 'せ', so: 'そ',
  za: 'ざ', ji: 'じ', zi: 'じ', zu: 'ず', ze: 'ぜ', zo: 'ぞ',
  ta: 'た', chi: 'ち', ti: 'ち', tsu: 'つ', tu: 'つ', te: 'て', to: 'と',
  da: 'だ', di: 'ぢ', du: 'づ', de: 'で', do: 'ど',
  na: 'な', ni: 'に', nu: 'ぬ', ne: 'ね', no: 'の',
  ha: 'は', hi: 'ひ', fu: 'ふ', hu: 'ふ', he: 'へ', ho: 'ほ',
  ba: 'ば', bi: 'び', bu: 'ぶ', be: 'べ', bo: 'ぼ',
  pa: 'ぱ', pi: 'ぴ', pu: 'ぷ', pe: 'ぺ', po: 'ぽ',
  ma: 'ま', mi: 'み', mu: 'む', me: 'め', mo: 'も',
  ya: 'や', yu: 'ゆ', yo: 'よ',
  ra: 'ら', ri: 'り', ru: 'る', re: 'れ', ro: 'ろ',
  wa: 'わ', wo: 'を',
  nn: 'ん', "n'": 'ん',

  // Digraphs (Yoon)
  kya: 'きゃ', kyu: 'きゅ', kyo: 'きょ',
  gya: 'ぎゃ', gyu: 'ぎゅ', gyo: 'ぎょ',
  sha: 'しゃ', shu: 'しゅ', sho: 'しょ',
  sya: 'しゃ', syu: 'しゅ', syo: 'しょ',
  ja: 'じゃ', ju: 'じゅ', jo: 'じょ',
  jya: 'じゃ', jyu: 'じゅ', jyo: 'じょ',
  cha: 'ちゃ', chu: 'ちゅ', cho: 'ちょ',
  tya: 'ちゃ', tyu: 'ちゅ', tyo: 'ちょ',
  nya: 'にゃ', nyu: 'にゅ', nyo: 'にょ',
  hya: 'ひゃ', hyu: 'ひゅ', hyo: 'ひょ',
  bya: 'びゃ', byu: 'びゅ', byo: 'びょ',
  pya: 'ぴゃ', pyu: 'ぴゅ', pyo: 'ぴょ',
  mya: 'みゃ', myu: 'みゅ', myo: 'みょ',
  rya: 'りゃ', ryu: 'りゅ', ryo: 'りょ',

  // Small kana
  fa: 'ふぁ', fi: 'ふぃ', fe: 'ふぇ', fo: 'ふぉ',
  va: 'ゔぁ', vi: 'ゔぃ', vu: 'ゔ', ve: 'ゔぇ', vo: 'ゔぉ',
  wi: 'うぃ', we: 'うぇ',
  '-': 'ー',
};

const KATAKANA_MAP: Record<string, string> = {
  a: 'ア', i: 'イ', u: 'ウ', e: 'エ', o: 'オ',
  ka: 'カ', ki: 'キ', ku: 'ク', ke: 'ケ', ko: 'コ',
  ga: 'ガ', gi: 'ギ', gu: 'グ', ge: 'ゲ', go: 'ゴ',
  sa: 'サ', shi: 'シ', si: 'シ', su: 'ス', se: 'セ', so: 'ソ',
  za: 'ザ', ji: 'ジ', zi: 'ジ', zu: 'ズ', ze: 'ゼ', zo: 'ゾ',
  ta: 'タ', chi: 'チ', ti: 'チ', tsu: 'ツ', tu: 'ツ', te: 'テ', to: 'ト',
  da: 'ダ', di: 'ヂ', du: 'ヅ', de: 'デ', do: 'ド',
  na: 'ナ', ni: 'ニ', nu: 'ヌ', ne: 'ネ', no: 'ノ',
  ha: 'ハ', hi: 'ヒ', fu: 'フ', hu: 'フ', he: 'ヘ', ho: 'ホ',
  ba: 'バ', bi: 'ビ', bu: 'ブ', be: 'ベ', bo: 'ボ',
  pa: 'パ', pi: 'ピ', pu: 'プ', pe: 'ペ', po: 'ポ',
  ma: 'マ', mi: 'ミ', mu: 'ム', me: 'メ', mo: 'モ',
  ya: 'ヤ', yu: 'ユ', yo: 'ヨ',
  ra: 'ラ', ri: 'リ', ru: 'ル', re: 'レ', ro: 'ロ',
  wa: 'ワ', wo: 'ヲ',
  nn: 'ン', "n'": 'ン',

  // Digraphs
  kya: 'キャ', kyu: 'キュ', kyo: 'キョ',
  gya: 'ギャ', gyu: 'ギュ', gyo: 'ギョ',
  sha: 'シャ', shu: 'シュ', sho: 'ショ',
  sya: 'シャ', syu: 'シュ', syo: 'ショ',
  ja: 'ジャ', ju: 'ジュ', jo: 'ジョ',
  jya: 'ジャ', jyu: 'ジュ', jyo: 'ジョ',
  cha: 'チャ', chu: 'チュ', cho: 'チョ',
  tya: 'チャ', tyu: 'チュ', tyo: 'チョ',
  nya: 'ニャ', nyu: 'ニュ', nyo: 'ニョ',
  hya: 'ヒャ', hyu: 'ヒュ', hyo: 'ヒョ',
  bya: 'ビャ', byu: 'ビュ', byo: 'ビョ',
  pya: 'ピャ', pyu: 'ピュ', pyo: 'ピョ',
  mya: 'ミャ', myu: 'ミュ', myo: 'ミョ',
  rya: 'リャ', ryu: 'リュ', ryo: 'リョ',

  fa: 'ファ', fi: 'フィ', fe: 'フェ', fo: 'フォ',
  va: 'ヴァ', vi: 'ヴィ', vu: 'ヴ', ve: 'ヴェ', vo: 'ヴォ',
  wi: 'ウィ', we: 'ウェ',
  '-': 'ー',
};

/**
 * Converts romaji input buffer into Hiragana or Katakana on-the-fly.
 * Handles double consonants (sokuon 'っ' or 'ッ') and 'n' rules.
 */
export function convertRomajiToKana(
  text: string,
  mode: 'hiragana' | 'katakana' = 'hiragana',
  finalizeTrailingN: boolean = false
): string {
  const map = mode === 'hiragana' ? HIRAGANA_MAP : KATAKANA_MAP;
  const sokuon = mode === 'hiragana' ? 'っ' : 'ッ';
  const nKana = mode === 'hiragana' ? 'ん' : 'ン';

  // Fix any existing artifacts like "あTM" / "あtm" -> "ATM"
  const normalizedText = (text || '').replace(/あtm/gi, 'ATM');

  let result = '';
  let i = 0;
  const lower = normalizedText.toLowerCase();

  while (i < lower.length) {
    // Preserve ATM acronym
    const remainingOrig = normalizedText.substring(i);
    const atmMatch = remainingOrig.match(/^atm(?=[^a-z]|$)/i);
    if (atmMatch) {
      result += 'ATM';
      i += 3;
      continue;
    }

    // Check if the current character is already a Japanese character (Hiragana, Katakana, Kanji, punctuation)
    const code = lower.charCodeAt(i);
    const isAsciiAlphabet = (code >= 97 && code <= 122) || code === 45; // a-z or '-'

    if (!isAsciiAlphabet) {
      result += normalizedText[i];
      i++;
      continue;
    }

    // Try match length 4, 3, 2, 1
    let matched = false;

    // Sokuon check: e.g. "kk", "tt", "ss", "pp", "tch"
    if (
      i + 1 < lower.length &&
      lower[i] !== 'n' &&
      lower[i] !== 'a' &&
      lower[i] !== 'i' &&
      lower[i] !== 'u' &&
      lower[i] !== 'e' &&
      lower[i] !== 'o'
    ) {
      if (lower[i] === lower[i + 1] || (lower[i] === 't' && lower.startsWith('tch', i))) {
        result += sokuon;
        i++;
        continue;
      }
    }

    // Single 'n' check: only convert if followed by an ASCII consonant (excluding y), apostrophe, or delimiter.
    // Or if finalizeTrailingN is true and it's at the end of the text.
    if (lower[i] === 'n') {
      const nextChar = lower[i + 1];
      if (nextChar) {
        const isAsciiConsonant = /^[bcdfghjklmnpqrstvwxz]$/i.test(nextChar);
        const isDelimiter = /^[\s.,!?;:()\[\]\-_/\\`"~]$/.test(nextChar);

        if (isAsciiConsonant || isDelimiter) {
          result += nKana;
          i++;
          // If next is another n or apostrophe, consume it
          if (nextChar === 'n' || nextChar === "'") {
            i++;
          }
          continue;
        }
      } else if (finalizeTrailingN) {
        result += nKana;
        i++;
        continue;
      }
    }

    for (let len = 4; len >= 1; len--) {
      if (i + len <= lower.length) {
        const sub = lower.substring(i, i + len);
        if (map[sub]) {
          result += map[sub];
          i += len;
          matched = true;
          break;
        }
      }
    }

    if (!matched) {
      // Keep character as is (e.g. pending incomplete syllable like 'k', 's')
      result += normalizedText[i];
      i++;
    }
  }

  return result;
}

/**
 * Text-to-speech for Japanese pronunciation using Web Speech Synthesis API
 */
export function speakJapanese(text: string, rate: number = 0.9): void {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

  try {
    window.speechSynthesis.cancel(); // Stop any pending speech

    // Remove parenthesis explanation, tildes, and turn slashes into natural pauses
    const cleanText = text
      .replace(/[\(（].*?[\)）]/g, '')
      .replace(/\[.*?\]/g, '')
      .replace(/[~～〜⁓〰^]/g, '')
      .replace(/[/／]+/g, '、 ')
      .trim();
    if (!cleanText) return;

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = 'ja-JP';
    utterance.rate = rate;

    // Find a native Japanese voice if available
    const voices = window.speechSynthesis.getVoices();
    const jaVoice = voices.find(
      (v) => v.lang.startsWith('ja') || v.name.toLowerCase().includes('japanese') || v.name.toLowerCase().includes('japan')
    );
    if (jaVoice) {
      utterance.voice = jaVoice;
    }

    window.speechSynthesis.speak(utterance);
  } catch (err) {
    console.warn('Speech synthesis error:', err);
  }
}

/**
 * Normalizes Japanese or input string for comparison:
 * - Trims whitespace
 * - Converts to lowercase
 * - Strips tildes / wave dashes (~, ～, 〜, ⁓, 〰)
 * - Strips punctuation, quotes, slashes, dashes, brackets, parentheses
 */
export function normalizeJapaneseText(str: string): string {
  if (!str) return '';
  return str
    .trim()
    .normalize('NFKC')
    .toLowerCase()
    // Convert any trailing or word-boundary Romaji 'n' to 'ん' (e.g. "かばn" -> "かばん", "gohan" -> "ごはん")
    .replace(/n(?=[^a-z]|$)/gi, 'ん')
    // Remove tildes and wave dashes: ASCII ~, fullwidth ～ (U+FF5E), wave dash 〜 (U+301C), etc.
    .replace(/[~～〜⁓〰^]/g, '')
    // Remove spaces, punctuation, slashes, dashes, parentheses
    .replace(/[\s\-_—–.,/／()（）[\]{}<>《》「」『』・、。!?:;"'‘’“”]/g, '');
}

/**
 * Extracts all valid target variants from a Japanese card field (term, reading, romaji).
 * Handles:
 * 1. Slashes / alternatives: "～ふん / ～ぷん" -> ["～ふん", "～ぷん"]
 * 2. Parentheses (optional prefix/suffix/word): "（お）しろ" -> ["しろ", "おしろ"]
 *    "たべます（たべる）" -> ["たべます", "たべる"]
 * 3. Tildes and wave dashes: "～じかん" -> matches with or without "～"
 */
export function extractJapaneseVariants(raw: string | undefined): string[] {
  if (!raw) return [];
  const text = raw.trim();
  if (!text) return [];

  // 1. Split alternatives separated by slashes, commas, semicolons or pipes
  const rawParts = text.split(/[/／,;、|]+/).map((p) => p.trim()).filter(Boolean);

  const results = new Set<string>();

  for (const part of rawParts) {
    if (!part) continue;

    // Add the part itself
    results.add(part);

    // Also version with tildes stripped directly
    const withoutTilde = part.replace(/[~～〜⁓〰^]/g, '').trim();
    if (withoutTilde) {
      results.add(withoutTilde);
    }

    // Check for parentheses (both ASCII () and Japanese fullwidth （）)
    const hasParens = /[\(（][^\)）]*[\)）]/.test(part);
    if (hasParens) {
      // 2a. Remove parenthesized text entirely: e.g. "（お）しろ" -> "しろ", "たべます（たべる）" -> "たべます"
      const withoutParens = part.replace(/[\(（][^\)）]*[\)）]/g, '').trim();
      if (withoutParens) {
        results.add(withoutParens);
        const withoutParensAndTilde = withoutParens.replace(/[~～〜⁓〰^]/g, '').trim();
        if (withoutParensAndTilde) results.add(withoutParensAndTilde);
      }

      // 2b. Keep parenthesized content, remove only the parenthesis symbols: e.g. "（お）しろ" -> "おしろ"
      const onlySymbolsRemoved = part.replace(/[\(（\)）]/g, '').trim();
      if (onlySymbolsRemoved) {
        results.add(onlySymbolsRemoved);
        const onlySymbolsRemovedAndTilde = onlySymbolsRemoved.replace(/[~～〜⁓〰^]/g, '').trim();
        if (onlySymbolsRemovedAndTilde) results.add(onlySymbolsRemovedAndTilde);
      }

      // 2c. Extract the text INSIDE parentheses: e.g. "たべます（たべる）" -> "たべる", "いく(ゆく)" -> "ゆく"
      const insideMatches = part.match(/[\(（]([^\)）]+)[\)）]/g);
      if (insideMatches) {
        for (const m of insideMatches) {
          const inner = m.replace(/[\(（\)）]/g, '').trim();
          if (inner) {
            results.add(inner);
            const innerWithoutTilde = inner.replace(/[~～〜⁓〰^]/g, '').trim();
            if (innerWithoutTilde) results.add(innerWithoutTilde);
          }
        }
      }
    }
  }

  return Array.from(results);
}

/**
 * Converts Katakana to Hiragana (Unicode U+30A1 - U+30F6 -> U+3041 - U+3096)
 */
export function katakanaToHiragana(str: string): string {
  if (!str) return '';
  return str.replace(/[\u30a1-\u30f6]/g, (ch) =>
    String.fromCharCode(ch.charCodeAt(0) - 0x60)
  );
}

/**
 * Converts Hiragana to Katakana (Unicode U+3041 - U+3096 -> U+30A1 - U+30F6)
 */
export function hiraganaToKatakana(str: string): string {
  if (!str) return '';
  return str.replace(/[\u3041-\u3096]/g, (ch) =>
    String.fromCharCode(ch.charCodeAt(0) + 0x60)
  );
}

/**
 * Normalizes text to canonical Hiragana for flexible Katakana <-> Hiragana matching
 */
export function toCanonicalKana(str: string): string {
  if (!str) return '';
  return katakanaToHiragana(normalizeJapaneseText(str));
}

/**
 * Checks if user answer matches target Japanese card.
 * Flexibly accepts:
 * - Direct Kanji / Kana match
 * - Hiragana typed when target is Katakana or Kanji
 * - Katakana typed when target is Hiragana or Kanji
 * - Romaji converted automatically
 */
export function checkJapaneseAnswer(
  userRawInput: string,
  card: { term: string; reading?: string; romaji?: string }
): boolean {
  const u = normalizeJapaneseText(userRawInput);
  if (!u) return false;

  const userCanonical = toCanonicalKana(userRawInput);
  const userConvertedHiragana = normalizeJapaneseText(convertRomajiToKana(userRawInput, 'hiragana', true));
  const userConvertedKatakana = normalizeJapaneseText(convertRomajiToKana(userRawInput, 'katakana', true));
  const userRomajiCanonical = toCanonicalKana(userConvertedHiragana);

  // Collect all valid target variants from card reading, term, and romaji
  const targetVariants = [
    ...extractJapaneseVariants(card.reading),
    ...extractJapaneseVariants(card.term),
    ...extractJapaneseVariants(card.romaji),
  ];

  for (const variant of targetVariants) {
    const normVariant = normalizeJapaneseText(variant);
    if (!normVariant) continue;

    // 1. Direct match with user input
    if (u === normVariant) {
      return true;
    }

    // 2. Canonical Kana match (converts Katakana <-> Hiragana interchangeably)
    const targetCanonical = toCanonicalKana(variant);
    if (targetCanonical && userCanonical === targetCanonical) {
      return true;
    }

    // 3. Match with user converted kana (Hiragana or Katakana)
    if (userConvertedHiragana && (userConvertedHiragana === normVariant || userRomajiCanonical === targetCanonical)) {
      return true;
    }
    if (userConvertedKatakana && userConvertedKatakana === normVariant) {
      return true;
    }

    // 4. Match with long vowel mark (ー) stripped
    if (
      userCanonical.replace(/ー/g, '') &&
      targetCanonical.replace(/ー/g, '') &&
      userCanonical.replace(/ー/g, '') === targetCanonical.replace(/ー/g, '')
    ) {
      return true;
    }
  }

  return false;
}

/**
 * Remove Vietnamese accents for flexible fuzzy matching
 */
export function removeVietnameseAccents(str: string): string {
  return str
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D');
}

/**
 * Checks if user answer matches target Vietnamese definition
 */
export function checkVietnameseAnswer(
  userRawInput: string,
  targetDefinition: string
): boolean {
  const clean = (s: string) =>
    s
      .trim()
      .toLowerCase()
      .replace(/[~～〜⁓〰^]/g, '')
      .replace(/[.,;:!?/\\／()（）[\]"'`]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

  const u = clean(userRawInput);
  if (!u) return false;

  const target = clean(targetDefinition);
  if (u === target) return true;

  // Split synonyms by comma, semicolon, slash, or parentheses
  const rawSegments = targetDefinition.split(/[,;/／+、|]+/);
  const segments: string[] = [];

  for (const rawSeg of rawSegments) {
    const c = clean(rawSeg);
    if (c) segments.push(c);

    // without parentheses
    const withoutParens = clean(rawSeg.replace(/[\(（][^\)）]*[\)）]/g, ''));
    if (withoutParens && withoutParens !== c) segments.push(withoutParens);

    // inside parentheses
    const insideMatches = rawSeg.match(/[\(（]([^\)）]+)[\)）]/g);
    if (insideMatches) {
      for (const m of insideMatches) {
        const inner = clean(m.replace(/[\(（\)）]/g, ''));
        if (inner) segments.push(inner);
      }
    }
  }

  for (const seg of segments) {
    if (u === seg) return true;
  }

  // Also check without accents
  const uNoAcc = removeVietnameseAccents(u);
  const targetNoAcc = removeVietnameseAccents(target);
  if (uNoAcc === targetNoAcc) return true;

  for (const seg of segments) {
    if (uNoAcc === removeVietnameseAccents(seg)) return true;
  }

  return false;
}
