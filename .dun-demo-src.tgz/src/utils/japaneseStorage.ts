import { notifyDataChanged } from './storageEvents';
import {
  JapaneseLesson,
  JapaneseVocabCard,
  JapaneseCourse,
  JapaneseKanjiCard,
  JapaneseGrammarPoint,
  JapaneseMaterial,
  AttachedFile,
} from '../types/japanese';
import { JPD123_GRAMMAR_POINTS } from '../data/jpd123Grammar';
import { JPD123_VOCAB_LESSONS } from '../data/jpd123Vocab';
import { JPD123_KANJI_LIST, JPD123_MATERIALS } from '../data/jpd123KanjiAndMaterials';
import {
  STRUCTURED_JPD123_LESSONS,
  ALL_KANJI_CORE_LIST,
  ALL_KANJI_VOCAB_LIST,
  JPD123_KANJI_FOLDERS,
} from '../data/jpd123StructuredLessons';
import { getCurrentUserEmail } from './storage';
import {
  syncJapaneseCourseToFirestore,
  deleteJapaneseCourseFromFirestore,
  saveJpd123AccessListToFirestore,
} from '../lib/firebase';
import { katakanaToHiragana } from './japaneseKana';

const STORAGE_KEY = 'mcq_japanese_lessons_v2';
const COURSES_STORAGE_KEY = 'mcq_japanese_courses_v1';
const JPD123_ACCESS_LIST_KEY = 'mcq_jpd123_allowed_emails';

// Primary Super Admin email
export const SUPER_ADMIN_EMAIL = 'daiduong4112006@gmail.com';

// Only these admin accounts have the JPD123 course folder
export const JAPANESE_ADMIN_EMAILS: string[] = [
  SUPER_ADMIN_EMAIL,
];

export function isJapaneseAdmin(email?: string | null): boolean {
  const targetEmail = (email !== undefined ? (email || '') : getCurrentUserEmail()).toLowerCase().trim();
  if (!targetEmail) return false;
  return JAPANESE_ADMIN_EMAILS.some((admin) => admin.toLowerCase().trim() === targetEmail);
}

export function getAllowedJpd123Emails(): string[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(JPD123_ACCESS_LIST_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {}
  return [];
}

export function saveAllowedJpd123Emails(emails: string[], skipCloudSync = false): void {
  if (typeof window === 'undefined') return;
  try {
    const cleanList = Array.from(new Set(emails.map((e) => e.trim().toLowerCase()).filter(Boolean)));
    localStorage.setItem(JPD123_ACCESS_LIST_KEY, JSON.stringify(cleanList));
    if (!skipCloudSync) {
      saveJpd123AccessListToFirestore(cleanList).catch(() => {});
    }
  } catch (e) {
    console.error('saveAllowedJpd123Emails error:', e);
  }
}

export function addJpd123AccessEmail(email: string): { success: boolean; message: string } {
  const clean = email.trim().toLowerCase();
  if (!clean || !clean.includes('@')) {
    return { success: false, message: 'Email không hợp lệ. Vui lòng nhập đúng định dạng Gmail!' };
  }
  if (isJapaneseAdmin(clean)) {
    return { success: false, message: 'Email này là Super Admin, đã có toàn quyền!' };
  }
  const current = getAllowedJpd123Emails();
  if (current.includes(clean)) {
    return { success: false, message: 'Email này đã được cấp quyền từ trước!' };
  }
  const next = [...current, clean];
  saveAllowedJpd123Emails(next);
  return { success: true, message: `Đã cấp quyền xem JPD123 thành công cho: ${clean}` };
}

export function removeJpd123AccessEmail(email: string): void {
  const clean = email.trim().toLowerCase();
  const current = getAllowedJpd123Emails();
  const next = current.filter((e) => e !== clean);
  saveAllowedJpd123Emails(next);
}

export function canAccessJpd123(email?: string | null): boolean {
  const targetEmail = (email !== undefined ? (email || '') : getCurrentUserEmail()).toLowerCase().trim();
  if (!targetEmail) return false;
  if (isJapaneseAdmin(targetEmail)) return true;
  const allowed = getAllowedJpd123Emails();
  return allowed.includes(targetEmail);
}

export function getCoursesStorageKey(email?: string | null): string {
  const targetEmail = (email !== undefined ? (email || '') : getCurrentUserEmail()).toLowerCase().trim();
  if (!targetEmail) return 'mcq_japanese_courses_v1_guest';
  const sanitized = targetEmail.replace(/[^a-z0-9]/g, '_');
  return `mcq_japanese_courses_v1_${sanitized}`;
}

export const SEED_JAPANESE_LESSONS: JapaneseLesson[] = [
  {
    id: 'jp-lesson-4-1',
    lessonCode: 'LESSON 4-1',
    title: '4-1: Phương hướng và phương tiện',
    description: 'Học về các phương hướng và phương tiện giao thông',
    level: 'N5',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    timesPracticed: 5,
    cards: [
      {
        id: 'jp-41-1',
        term: '北',
        reading: 'きた',
        romaji: 'kita',
        partOfSpeech: 'Danh từ',
        definition: 'Phía bắc',
        example: 'Gió lạnh thổi từ phía bắc.',
        mastered: false,
      },
      {
        id: 'jp-41-2',
        term: '南',
        reading: 'みなみ',
        romaji: 'minami',
        partOfSpeech: 'Danh từ',
        definition: 'Phía nam',
        example: 'Đi du lịch về phía nam.',
        mastered: false,
      },
      {
        id: 'jp-41-3',
        term: '東',
        reading: 'ひがし',
        romaji: 'higashi',
        partOfSpeech: 'Danh từ',
        definition: 'Phía đông',
        example: 'Mặt trời mọc ở hướng đông.',
        mastered: false,
      },
      {
        id: 'jp-41-4',
        term: '西',
        reading: 'にし',
        romaji: 'nishi',
        partOfSpeech: 'Danh từ',
        definition: 'Phía tây',
        example: 'Mặt trời lặn ở hướng tây.',
        mastered: false,
      },
      {
        id: 'jp-41-5',
        term: '電車',
        reading: 'でんしゃ',
        romaji: 'densha',
        partOfSpeech: 'Danh từ',
        definition: 'Tàu điện',
        example: 'Lên tàu điện đi làm.',
        mastered: false,
      },
      {
        id: 'jp-41-6',
        term: '駅',
        reading: 'えき',
        romaji: 'eki',
        partOfSpeech: 'Danh từ',
        definition: 'Nhà ga',
        example: 'Hẹn gặp bạn bè ở trước nhà ga.',
        mastered: false,
      },
      {
        id: 'jp-41-7',
        term: '車',
        reading: 'くるま',
        romaji: 'kuruma',
        partOfSpeech: 'Danh từ',
        definition: 'Xe ô tô',
        example: 'Lái xe ô tô về quê.',
        mastered: false,
      },
      {
        id: 'jp-41-8',
        term: '自転車',
        reading: 'じてんしゃ',
        romaji: 'jitensha',
        partOfSpeech: 'Danh từ',
        definition: 'Xe đạp',
        example: 'Đi dạo quanh hồ bằng xe đạp.',
        mastered: false,
      },
      {
        id: 'jp-41-9',
        term: 'バス',
        reading: 'ばす',
        romaji: 'basu',
        partOfSpeech: 'Danh từ',
        definition: 'Xe buýt',
        example: 'Chờ tuyến xe buýt số 12.',
        mastered: false,
      },
      {
        id: 'jp-41-10',
        term: '飛行機',
        reading: 'ひこうき',
        romaji: 'hikouki',
        partOfSpeech: 'Danh từ',
        definition: 'Máy bay',
        example: 'Đi Tokyo bằng máy bay.',
        mastered: false,
      },
      {
        id: 'jp-41-11',
        term: '右',
        reading: 'みぎ',
        romaji: 'migi',
        partOfSpeech: 'Danh từ',
        definition: 'Bên phải',
        example: 'Rẽ sang bên phải ở ngã tư.',
        mastered: false,
      },
      {
        id: 'jp-41-12',
        term: '左',
        reading: 'ひだり',
        romaji: 'hidari',
        partOfSpeech: 'Danh từ',
        definition: 'Bên trái',
        example: 'Bưu điện nằm ở phía bên trái.',
        mastered: false,
      },
      {
        id: 'jp-41-13',
        term: 'まっすぐ',
        reading: 'まっすぐ',
        romaji: 'massugu',
        partOfSpeech: 'Phó từ',
        definition: 'Đi thẳng',
        example: 'Hãy đi thẳng đường này 200 mét.',
        mastered: false,
      },
      {
        id: 'jp-41-14',
        term: '近く',
        reading: 'ちかく',
        romaji: 'chikaku',
        partOfSpeech: 'Danh từ',
        definition: 'Gần đây',
        example: 'Có siêu thị tiện lợi ở gần đây không?',
        mastered: false,
      },
    ],
  },
  {
    id: 'jp-lesson-4-2',
    lessonCode: 'LESSON 4-2',
    title: '4-2: Địa điểm và tính từ',
    description: 'Học về các địa điểm và tính từ miêu tả',
    level: 'N5',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    timesPracticed: 2,
    cards: [
      {
        id: 'jp-42-1',
        term: '学校',
        reading: 'がっこう',
        romaji: 'gakkou',
        partOfSpeech: 'Danh từ',
        definition: 'Trường học',
        example: 'Học sinh đến trường lúc 8 giờ.',
        mastered: false,
      },
      {
        id: 'jp-42-2',
        term: '病院',
        reading: 'びょういん',
        romaji: 'byouin',
        partOfSpeech: 'Danh từ',
        definition: 'Bệnh viện',
        example: 'Bác sĩ làm việc tại bệnh viện.',
        mastered: false,
      },
      {
        id: 'jp-42-3',
        term: '銀行',
        reading: 'ぎんこう',
        romaji: 'ginkou',
        partOfSpeech: 'Danh từ',
        definition: 'Ngân hàng',
        example: 'Rút tiền ở ngân hàng.',
        mastered: false,
      },
      {
        id: 'jp-42-4',
        term: '公園',
        reading: 'こうえん',
        romaji: 'kouen',
        partOfSpeech: 'Danh từ',
        definition: 'Công viên',
        example: 'Đi dạo ngắm hoa ở công viên.',
        mastered: false,
      },
      {
        id: 'jp-42-5',
        term: '大きい',
        reading: 'おおきい',
        romaji: 'ookii',
        partOfSpeech: 'Tính từ đuôi い',
        definition: 'To lớn',
        example: 'Tòa nhà này rất to lớn.',
        mastered: false,
      },
      {
        id: 'jp-42-6',
        term: '小さい',
        reading: 'ちいさい',
        romaji: 'chiisai',
        partOfSpeech: 'Tính từ đuôi い',
        definition: 'Nhỏ bé',
        example: 'Một chú mèo con nhỏ bé.',
        mastered: false,
      },
      {
        id: 'jp-42-7',
        term: '新しい',
        reading: 'あたらしい',
        romaji: 'atarashii',
        partOfSpeech: 'Tính từ đuôi い',
        definition: 'Mới',
        example: 'Mua chiếc điện thoại mới.',
        mastered: false,
      },
      {
        id: 'jp-42-8',
        term: '古い',
        reading: 'ふるい',
        romaji: 'furui',
        partOfSpeech: 'Tính từ đuôi い',
        definition: 'Cũ, cổ kính',
        example: 'Ngôi chùa cổ kính ở Kyoto.',
        mastered: false,
      },
    ],
  },
  {
    id: 'jp-lesson-4-3',
    lessonCode: 'LESSON 4-3',
    title: '4-3: Thời tiết và vị giác',
    description: 'Học về thời tiết và các vị của thức ăn',
    level: 'N5',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    timesPracticed: 1,
    cards: [
      {
        id: 'jp-43-1',
        term: '晴れ',
        reading: 'はれ',
        romaji: 'hare',
        partOfSpeech: 'Danh từ',
        definition: 'Trời nắng đẹp',
        example: 'Hôm nay thời tiết nắng ráo.',
        mastered: false,
      },
      {
        id: 'jp-43-2',
        term: '雨',
        reading: 'あめ',
        romaji: 'ame',
        partOfSpeech: 'Danh từ',
        definition: 'Trời mưa',
        example: 'Mang theo ô vì trời mưa.',
        mastered: false,
      },
      {
        id: 'jp-43-3',
        term: '暑い',
        reading: 'あつい',
        romaji: 'atsui',
        partOfSpeech: 'Tính từ đuôi い',
        definition: 'Nóng nực',
        example: 'Mùa hè ở Tokyo rất nóng.',
        mastered: false,
      },
      {
        id: 'jp-43-4',
        term: '寒い',
        reading: 'さむい',
        romaji: 'samui',
        partOfSpeech: 'Tính từ đuôi い',
        definition: 'Lạnh lẽo',
        example: 'Mùa đông tuyết rơi lạnh lẽo.',
        mastered: false,
      },
      {
        id: 'jp-43-5',
        term: 'おいしい',
        reading: 'おいしい',
        romaji: 'oishii',
        partOfSpeech: 'Tính từ đuôi い',
        definition: 'Ngon',
        example: 'Món ăn Nhật Bản rất ngon.',
        mastered: false,
      },
      {
        id: 'jp-43-6',
        term: '甘い',
        reading: 'あまい',
        romaji: 'amai',
        partOfSpeech: 'Tính từ đuôi い',
        definition: 'Ngọt ngào',
        example: 'Bánh kem rất ngọt ngào.',
        mastered: false,
      },
      {
        id: 'jp-43-7',
        term: '辛い',
        reading: 'からい',
        romaji: 'karai',
        partOfSpeech: 'Tính từ đuôi い',
        definition: 'Cay',
        example: 'Món mì cay này rất hấp dẫn.',
        mastered: false,
      },
    ],
  },
  {
    id: 'jp-lesson-5-1',
    lessonCode: 'LESSON 5-1',
    title: '5-1: Thời gian và hoạt động',
    description: 'Học về các mốc thời gian và hoạt động hàng ngày',
    level: 'N5',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    timesPracticed: 3,
    cards: [
      {
        id: 'jp-51-1',
        term: '朝',
        reading: 'あさ',
        romaji: 'asa',
        partOfSpeech: 'Danh từ',
        definition: 'Buổi sáng',
        example: 'Thức dậy vào sáng sớm.',
        mastered: false,
      },
      {
        id: 'jp-51-2',
        term: '昼',
        reading: 'ひる',
        romaji: 'hiru',
        partOfSpeech: 'Danh từ',
        definition: 'Buổi trưa',
        example: 'Ăn cơm trưa lúc 12 giờ.',
        mastered: false,
      },
      {
        id: 'jp-51-3',
        term: '夜',
        reading: 'よる',
        romaji: 'yoru',
        partOfSpeech: 'Danh từ',
        definition: 'Buổi tối, ban đêm',
        example: 'Học bài vào buổi tối.',
        mastered: false,
      },
      {
        id: 'jp-51-4',
        term: '起きる',
        reading: 'おきる',
        romaji: 'okiru',
        partOfSpeech: 'Động từ',
        definition: 'Thức dậy',
        example: 'Thức dậy lúc 6 giờ sáng.',
        mastered: false,
      },
      {
        id: 'jp-51-5',
        term: '寝る',
        reading: 'ねる',
        romaji: 'neru',
        partOfSpeech: 'Động từ',
        definition: 'Đi ngủ',
        example: 'Đi ngủ lúc 11 giờ đêm.',
        mastered: false,
      },
      {
        id: 'jp-51-6',
        term: '勉強する',
        reading: 'べんきょうする',
        romaji: 'benkyousuru',
        partOfSpeech: 'Động từ',
        definition: 'Học tập',
        example: 'Học tiếng Nhật mỗi ngày.',
        mastered: false,
      },
    ],
  },
  {
    id: 'jp-lesson-5-2',
    lessonCode: 'LESSON 5-2',
    title: '5-2: Thời tiết và cảm xúc',
    description: 'Học về thời tiết và các tính từ chỉ cảm giác, trạng thái',
    level: 'N5',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    timesPracticed: 1,
    cards: [
      {
        id: 'jp-52-1',
        term: '嬉しい',
        reading: 'うれしい',
        romaji: 'ureshii',
        partOfSpeech: 'Tính từ đuôi い',
        definition: 'Vui mừng, hạnh phúc',
        example: 'Rất vui mừng khi thi đỗ.',
        mastered: false,
      },
      {
        id: 'jp-52-2',
        term: '楽しい',
        reading: 'たのしい',
        romaji: 'tanoshii',
        partOfSpeech: 'Tính từ đuôi い',
        definition: 'Vui vẻ, thú vị',
        example: 'Chuyến đi chơi rất vui vẻ.',
        mastered: false,
      },
      {
        id: 'jp-52-3',
        term: '忙しい',
        reading: 'いそがしい',
        romaji: 'isogashii',
        partOfSpeech: 'Tính từ đuôi い',
        definition: 'Bận rộn',
        example: 'Công việc tuần này rất bận rộn.',
        mastered: false,
      },
      {
        id: 'jp-52-4',
        term: '暇',
        reading: 'ひま',
        romaji: 'hima',
        partOfSpeech: 'Tính từ đuôi な',
        definition: 'Rảnh rỗi',
        example: 'Chủ nhật này bạn có rảnh không?',
        mastered: false,
      },
    ],
  },
  {
    id: 'jp-lesson-5-3',
    lessonCode: 'LESSON 5-3',
    title: '5-3: Sở thích',
    description: 'Học về các sở thích và hoạt động giải trí',
    level: 'N5',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    timesPracticed: 2,
    cards: [
      {
        id: 'jp-53-1',
        term: '音楽',
        reading: 'おんがく',
        romaji: 'ongaku',
        partOfSpeech: 'Danh từ',
        definition: 'Âm nhạc',
        example: 'Nghe âm nhạc thư giãn.',
        mastered: false,
      },
      {
        id: 'jp-53-2',
        term: '映画',
        reading: 'えいが',
        romaji: 'eiga',
        partOfSpeech: 'Danh từ',
        definition: 'Phim ảnh',
        example: 'Xem phim chiếu rạp cùng bạn.',
        mastered: false,
      },
      {
        id: 'jp-53-3',
        term: '読書',
        reading: 'どくしょ',
        romaji: 'dokusho',
        partOfSpeech: 'Danh từ',
        definition: 'Đọc sách',
        example: 'Sở thích của tôi là đọc sách.',
        mastered: false,
      },
      {
        id: 'jp-53-4',
        term: '旅行',
        reading: 'りょこう',
        romaji: 'ryokou',
        partOfSpeech: 'Danh từ',
        definition: 'Du lịch',
        example: 'Đi du lịch Nhật Bản mùa hoa anh đào.',
        mastered: false,
      },
      {
        id: 'jp-53-5',
        term: '料理',
        reading: 'りょうり',
        romaji: 'ryouri',
        partOfSpeech: 'Danh từ',
        definition: 'Nấu ăn, món ăn',
        example: 'Nấu các món ăn ngon.',
        mastered: false,
      },
    ],
  },
  {
    id: 'jp-lesson-6-1',
    lessonCode: 'LESSON 6-1',
    title: '6-1: Kế hoạch và sự kiện',
    description: 'Học về kế hoạch, sự kiện và cách đếm vật mỏng',
    level: 'N5',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    timesPracticed: 1,
    cards: [
      {
        id: 'jp-61-1',
        term: '計画',
        reading: 'けいかく',
        romaji: 'keikaku',
        partOfSpeech: 'Danh từ',
        definition: 'Kế hoạch',
        example: 'Lập kế hoạch cho năm mới.',
        mastered: false,
      },
      {
        id: 'jp-61-2',
        term: '約束',
        reading: 'やくそく',
        romaji: 'yakusoku',
        partOfSpeech: 'Danh từ',
        definition: 'Cuộc hẹn, lời hứa',
        example: 'Có cuộc hẹn lúc 7 giờ tối.',
        mastered: false,
      },
      {
        id: 'jp-61-3',
        term: '会議',
        reading: 'かいぎ',
        romaji: 'kaigi',
        partOfSpeech: 'Danh từ',
        definition: 'Cuộc họp',
        example: 'Tham gia cuộc họp quan trọng.',
        mastered: false,
      },
      {
        id: 'jp-61-4',
        term: '誕生日',
        reading: 'たんじょうび',
        romaji: 'tanjoubi',
        partOfSpeech: 'Danh từ',
        definition: 'Ngày sinh nhật',
        example: 'Chúc mừng sinh nhật bạn!',
        mastered: false,
      },
      {
        id: 'jp-61-5',
        term: '枚',
        reading: 'まい',
        romaji: 'mai',
        partOfSpeech: 'Lượng từ',
        definition: 'Tờ, tấm (đếm vật mỏng)',
        example: 'Mua 2 tấm vé xem phim.',
        mastered: false,
      },
    ],
  },
  {
    id: 'jp-lesson-6-2',
    lessonCode: 'LESSON 6-2',
    title: '6-2: Ăn uống và giải trí',
    description: 'Học về đồ ăn, thức uống và các hoạt động giải trí',
    level: 'N5',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    timesPracticed: 2,
    cards: [
      {
        id: 'jp-62-1',
        term: 'ご飯',
        reading: 'ごはん',
        romaji: 'gohan',
        partOfSpeech: 'Danh từ',
        definition: 'Cơm, bữa ăn',
        example: 'Cùng nhau ăn cơm nhé.',
        mastered: false,
      },
      {
        id: 'jp-62-2',
        term: 'パン',
        reading: 'ぱん',
        romaji: 'pan',
        partOfSpeech: 'Danh từ',
        definition: 'Bánh mì',
        example: 'Ăn bánh mì vào buổi sáng.',
        mastered: false,
      },
      {
        id: 'jp-62-3',
        term: '肉',
        reading: 'にく',
        romaji: 'niku',
        partOfSpeech: 'Danh từ',
        definition: 'Thịt',
        example: 'Thịt bò nướng thơm ngon.',
        mastered: false,
      },
      {
        id: 'jp-62-4',
        term: '魚',
        reading: 'さかな',
        romaji: 'sakana',
        partOfSpeech: 'Danh từ',
        definition: 'Cá',
        example: 'Ăn cá tươi ngon.',
        mastered: false,
      },
      {
        id: 'jp-62-5',
        term: 'カラオケ',
        reading: 'からおけ',
        romaji: 'karaoke',
        partOfSpeech: 'Danh từ',
        definition: 'Hát Karaoke',
        example: 'Cuối tuần đi hát karaoke.',
        mastered: false,
      },
    ],
  },
  {
    id: 'jp-lesson-6-3',
    lessonCode: 'LESSON 6-3',
    title: '6-3: Ẩm thực Nhật',
    description: 'Học về các món ăn đặc trưng của Nhật Bản',
    level: 'N5',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    timesPracticed: 4,
    cards: [
      {
        id: 'jp-63-1',
        term: '寿司',
        reading: 'すし',
        romaji: 'sushi',
        partOfSpeech: 'Danh từ',
        definition: 'Món Sushi',
        example: 'Sushi cá hồi rất tươi ngon.',
        mastered: false,
      },
      {
        id: 'jp-63-2',
        term: 'ラーメン',
        reading: 'らーめん',
        romaji: 'raamen',
        partOfSpeech: 'Danh từ',
        definition: 'Mì Ramen',
        example: 'Thưởng thức tô mì Ramen nóng hổi.',
        mastered: false,
      },
      {
        id: 'jp-63-3',
        term: '天ぷら',
        reading: 'てんぷら',
        romaji: 'tenpura',
        partOfSpeech: 'Danh từ',
        definition: 'Món Tempura (chiên giòn)',
        example: 'Tempura tôm chiên vàng giòn.',
        mastered: false,
      },
      {
        id: 'jp-63-4',
        term: '刺身',
        reading: 'さしみ',
        romaji: 'sashimi',
        partOfSpeech: 'Danh từ',
        definition: 'Món Sashimi',
        example: 'Đĩa Sashimi hải sản cao cấp.',
        mastered: false,
      },
      {
        id: 'jp-63-5',
        term: '抹茶',
        reading: 'まっちゃ',
        romaji: 'matcha',
        partOfSpeech: 'Danh từ',
        definition: 'Trà xanh Matcha',
        example: 'Uống một tách trà xanh Matcha nguyên chất.',
        mastered: false,
      },
    ],
  },
];

export function getJapaneseLessons(): JapaneseLesson[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      // Start fresh with empty list so user adds their own lessons
      localStorage.setItem(STORAGE_KEY, JSON.stringify([]));
      return [];
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return parsed;
    }
    return [];
  } catch (e) {
    console.error('Failed to load Japanese lessons:', e);
    return [];
  }
}

export function saveJapaneseLesson(lesson: JapaneseLesson): JapaneseLesson[] {
  const current = getJapaneseLessons();
  const existsIndex = current.findIndex((l) => l.id === lesson.id);
  let updated: JapaneseLesson[];

  if (existsIndex >= 0) {
    updated = [...current];
    updated[existsIndex] = {
      ...lesson,
      updatedAt: new Date().toISOString(),
    };
  } else {
    updated = [
      {
        ...lesson,
        createdAt: lesson.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      ...current,
    ];
  }

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error('Failed to persist Japanese lessons:', e);
  }
  return updated;
}

export function deleteJapaneseLesson(id: string): JapaneseLesson[] {
  const current = getJapaneseLessons();
  const updated = current.filter((l) => l.id !== id);
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error('Failed to delete Japanese lesson:', e);
  }
  return updated;
}

export function clearAllLessons(): JapaneseLesson[] {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify([]));
  } catch (e) {
    console.error('Failed to clear all Japanese lessons:', e);
  }
  return [];
}

export function getJapaneseLessonById(id: string): JapaneseLesson | null {
  const lessons = getJapaneseLessons();
  return lessons.find((l) => l.id === id) || null;
}

export function updateJapaneseCardMastery(lessonId: string, cardId: string, mastered: boolean): void {
  const lessons = getJapaneseLessons();
  const lesson = lessons.find((l) => l.id === lessonId);
  if (!lesson) return;

  const card = lesson.cards.find((c) => c.id === cardId);
  if (card) {
    card.mastered = mastered;
    saveJapaneseLesson(lesson);
  }
}

// ---------------------------------------------------------------------------
// Japanese Courses Management (e.g. JPD123)
// ---------------------------------------------------------------------------

// Chữ Hán đã bỏ khỏi giáo trình: 南 (L4), 肉 料 理 野 半 (L7)
export const REMOVED_JPD123_KANJI_IDS: string[] = [
  'k-l4-6',
  'k-minami',
  'k-l7-7',
  'k-l7-8',
  'k-l7-9',
  'k-l7-10',
  'k-l7-11',
];

export const JPD123_GRAMMAR_VERSION = '20261103_v5_docx_rebuild';

export const DEFAULT_JPD123_COURSE: JapaneseCourse = {
  id: 'course-jpd123',
  code: 'JPD 123',
  title: 'Tiếng Nhật JPD 123 (Bài 4 - 7)',
  description: 'Khóa học tiếng Nhật JPD123 toàn diện - Tổng hợp Từ vựng, Chữ Hán và Ngữ pháp Bài 4-7',
  level: 'N5',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  grammarVersion: JPD123_GRAMMAR_VERSION,
  lessons: JPD123_VOCAB_LESSONS,
  kanjiList: ALL_KANJI_CORE_LIST,
  kanjiVocabList: ALL_KANJI_VOCAB_LIST,
  grammarPoints: JPD123_GRAMMAR_POINTS,
  materials: JPD123_MATERIALS,
};

// Returns a fresh, 100% unstarted instance of JPD123 where no cards are mastered
export function getCleanDefaultJpdCourse(): JapaneseCourse {
  return {
    ...DEFAULT_JPD123_COURSE,
    grammarVersion: JPD123_GRAMMAR_VERSION,
    lessons: (DEFAULT_JPD123_COURSE.lessons || []).map((l) => ({
      ...l,
      timesPracticed: 0,
      cards: (l.cards || []).map((c) => ({ ...c, mastered: false })),
      kanjiCore: (l.kanjiCore || []).map((k) => ({ ...k, mastered: false })),
    })),
    kanjiList: (DEFAULT_JPD123_COURSE.kanjiList || []).map((k) => ({ ...k, mastered: false })),
    kanjiVocabList: (DEFAULT_JPD123_COURSE.kanjiVocabList || []).map((v) => ({ ...v, mastered: false })),
  };
}

// Ensures JPD123 course always has the latest grammar points, examples, vocabulary, and kanji
export function ensureJpdCourseUpToDate(course: JapaneseCourse): { course: JapaneseCourse; changed: boolean } {
  if (!course || (course.id !== 'course-jpd123' && course.code?.toLowerCase().replace(/\s+/g, '') !== 'jpd123')) {
    return { course, changed: false };
  }
  let changed = false;
  const updated: JapaneseCourse = { ...course };

  if (!Array.isArray(updated.grammarPoints)) {
    updated.grammarPoints = JPD123_GRAMMAR_POINTS;
    updated.grammarVersion = JPD123_GRAMMAR_VERSION;
    changed = true;
  } else {
    const nextGrammar = [...updated.grammarPoints];
    const isVersionOutdated = updated.grammarVersion !== JPD123_GRAMMAR_VERSION;

    for (const defGp of JPD123_GRAMMAR_POINTS) {
      const existingIdx = nextGrammar.findIndex((g: JapaneseGrammarPoint) => g.id === defGp.id);
      if (existingIdx !== -1) {
        const existing = nextGrammar[existingIdx];
        // If course grammar version is outdated and the user has NOT custom-edited this point:
        // Safely sync to the audited clean vocabulary version while preserving any attached files
        if (isVersionOutdated && !existing.isCustom) {
          nextGrammar[existingIdx] = {
            ...defGp,
            attachedFiles: existing.attachedFiles || defGp.attachedFiles,
          };
          changed = true;
        }
      } else if (isVersionOutdated && !(updated.deletedGrammarIds || []).includes(defGp.id)) {
        nextGrammar.push(defGp); changed = true;
      }
    }
    updated.grammarPoints = nextGrammar;
    if (isVersionOutdated) {
      updated.grammarVersion = JPD123_GRAMMAR_VERSION;
      changed = true;
    }
  }

  const hasOldKanjiLessons =
    !Array.isArray(updated.lessons) ||
    updated.lessons.some((l: JapaneseLesson) => l.id.startsWith('lesson-jpd123-l'));
  if (hasOldKanjiLessons) {
    updated.lessons = JPD123_VOCAB_LESSONS;
    changed = true;
  }

  // Chữ Hán đã bị bỏ khỏi giáo trình JPD123 → xóa luôn khỏi dữ liệu đã lưu (local + cloud)
  if (Array.isArray(updated.kanjiList)) {
    const before = updated.kanjiList.length;
    updated.kanjiList = updated.kanjiList.filter(
      (k: JapaneseKanjiCard) => !REMOVED_JPD123_KANJI_IDS.includes(k.id)
    );
    if (updated.kanjiList.length !== before) changed = true;
  }

  if (!Array.isArray(updated.kanjiList)) {
    updated.kanjiList = ALL_KANJI_CORE_LIST;
    changed = true;
  }

  if (!Array.isArray(updated.kanjiVocabList)) {
    updated.kanjiVocabList = ALL_KANJI_VOCAB_LIST;
    changed = true;
  }

  if (updated.materials === undefined) {
    updated.materials = JPD123_MATERIALS;
    changed = true;
  } else if (Array.isArray(updated.deletedMaterialIds) && updated.deletedMaterialIds.length > 0) {
    const beforeCount = updated.materials.length;
    updated.materials = updated.materials.filter(
      (m: JapaneseMaterial) => !updated.deletedMaterialIds!.includes(m.id)
    );
    if (updated.materials.length !== beforeCount) {
      changed = true;
    }
  }

  if (Array.isArray(updated.lessons)) {
    // Lookup map for standard lesson cards to enrich example and exampleMeaning
    const defaultCardsMap = new Map<string, JapaneseVocabCard>();
    for (const l of JPD123_VOCAB_LESSONS) {
      for (const c of l.cards || []) {
        defaultCardsMap.set(c.id, c);
        if (!defaultCardsMap.has(c.term)) {
          defaultCardsMap.set(c.term, c);
        }
      }
    }

    for (const lesson of updated.lessons) {
      for (const card of lesson.cards || []) {
        const isKata = /[\u30A0-\u30FF]/.test(card.term) && !/[\u4E00-\u9FAF]/.test(card.term);
        if (isKata && (!card.reading || card.reading === card.term)) {
          card.reading = katakanaToHiragana(card.term);
          changed = true;
        }

        const defCard = defaultCardsMap.get(card.id) || defaultCardsMap.get(card.term);
        if (defCard) {
          if (defCard.example && !card.example) {
            card.example = defCard.example;
            changed = true;
          }
          if (defCard.exampleMeaning && !card.exampleMeaning) {
            card.exampleMeaning = defCard.exampleMeaning;
            changed = true;
          }
        }
      }
    }
  }

  return { course: updated, changed };
}

export function getJapaneseCourses(email?: string | null): JapaneseCourse[] {
  if (typeof window === 'undefined') return [];
  try {
    const targetEmail = (email !== undefined ? (email || '') : getCurrentUserEmail()).toLowerCase().trim();
    const hasAccess = canAccessJpd123(targetEmail);
    const userKey = getCoursesStorageKey(targetEmail);

    if (hasAccess) {
      let raw = localStorage.getItem(userKey);
      // Migrate from legacy global key if user key does not exist yet (ONLY for Super Admin to prevent data leakage!)
      if (!raw && isJapaneseAdmin(targetEmail)) {
        const legacyRaw = localStorage.getItem(COURSES_STORAGE_KEY);
        if (legacyRaw) {
          raw = legacyRaw;
          localStorage.setItem(userKey, legacyRaw);
        }
      }

      if (!raw) {
        // Brand new user gets 100% clean instance of JPD123 (never starts with someone else's progress!)
        const initialList = getDeletedJapaneseCourseIds(targetEmail).includes('course-jpd123') ? [] : [getCleanDefaultJpdCourse()];
        localStorage.setItem(userKey, JSON.stringify(initialList));
        return initialList;
      }

      let parsed: any = [];
      try {
        parsed = raw ? JSON.parse(raw) : [];
      } catch {
        parsed = [];
      }
      if (!Array.isArray(parsed)) parsed = [];

      // Ensure course-jpd123 has full data for Lessons 4-7 or restore if deleted
      let changed = false;
      const jpdIdx = parsed.findIndex((c: JapaneseCourse) => c && (c.id === 'course-jpd123' || c.code?.toLowerCase().replace(/\s+/g, '') === 'jpd123'));
      if (jpdIdx !== -1) {
        const res = ensureJpdCourseUpToDate(parsed[jpdIdx]);
        if (res.changed) {
          parsed[jpdIdx] = res.course;
          changed = true;
        }
      } else if (!getDeletedJapaneseCourseIds(targetEmail).includes('course-jpd123')) {
        // Seed only when the course was not explicitly deleted.
        parsed.unshift(DEFAULT_JPD123_COURSE);
        changed = true;
        if (isJapaneseAdmin(targetEmail)) {
          syncJapaneseCourseToFirestore(DEFAULT_JPD123_COURSE).catch(() => {});
        }
      }
      if (changed) {
        localStorage.setItem(userKey, JSON.stringify(parsed));
      }
      return parsed;
    }

    // Non-admin account (or guest): Must NEVER have jpd123, completely empty by default!
    const raw = localStorage.getItem(userKey);
    if (!raw) {
      return [];
    }

    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      // Clean out any JPD123 course if it was somehow copied or stored
      const sanitized = parsed.filter(
        (c: JapaneseCourse) =>
          c &&
          c.id !== 'course-jpd123' &&
          c.code?.toLowerCase().replace(/\s+/g, '') !== 'jpd123'
      );
      if (sanitized.length !== parsed.length) {
        localStorage.setItem(userKey, JSON.stringify(sanitized));
      }
      return sanitized;
    }

    return [];
  } catch (e) {
    console.error('Failed to load Japanese courses:', e);
    return [];
  }
}

// Helper to clean personal mastery and practice stats when syncing curriculum to Cloud Firestore
export function cleanCurriculumForCloud(course: JapaneseCourse): JapaneseCourse {
  return {
    ...course,
    lessons: (course.lessons || []).map((l) => ({
      ...l,
      timesPracticed: 0,
      cards: (l.cards || []).map((c) => ({
        ...c,
        mastered: false,
      })),
      kanjiCore: (l.kanjiCore || []).map((k) => ({
        ...k,
        mastered: false,
      })),
    })),
    kanjiList: (course.kanjiList || []).map((k) => ({
      ...k,
      mastered: false,
    })),
    kanjiVocabList: (course.kanjiVocabList || []).map((v) => ({
      ...v,
      mastered: false,
    })),
  };
}

// Helper to merge incoming cloud curriculum with local user's personal learning progress (mastered cards, timesPracticed)
export function mergeCourseWithLocalMastery(cloudCourse: JapaneseCourse, localCourse?: JapaneseCourse | null): JapaneseCourse {
  if (!localCourse) return cloudCourse;

  const localCardMastery = new Map<string, boolean>();
  for (const l of (localCourse.lessons || [])) {
    for (const c of (l.cards || [])) {
      if (c.mastered !== undefined) {
        localCardMastery.set(c.id, c.mastered);
      }
    }
  }

  const localKanjiMastery = new Map<string, boolean>();
  for (const k of (localCourse.kanjiList || [])) {
    if (k.mastered !== undefined) {
      localKanjiMastery.set(k.id, k.mastered);
    }
  }

  const localKanjiVocabMastery = new Map<string, boolean>();
  for (const v of (localCourse.kanjiVocabList || [])) {
    if (v.mastered !== undefined) {
      localKanjiVocabMastery.set(v.id, v.mastered);
    }
  }

  const localTimesPracticed = new Map<string, number>();
  for (const l of (localCourse.lessons || [])) {
    if (l.timesPracticed !== undefined) {
      localTimesPracticed.set(l.id, l.timesPracticed);
    }
  }

  return {
    ...cloudCourse,
    lessons: (cloudCourse.lessons || []).map((l) => ({
      ...l,
      timesPracticed: localTimesPracticed.get(l.id) ?? l.timesPracticed ?? 0,
      cards: (l.cards || []).map((c) => ({
        ...c,
        mastered: localCardMastery.get(c.id) ?? c.mastered ?? false,
      })),
      kanjiCore: (l.kanjiCore || []).map((k) => ({
        ...k,
        mastered: localKanjiMastery.get(k.id) ?? k.mastered ?? false,
      })),
    })),
    kanjiList: (cloudCourse.kanjiList || []).map((k) => ({
      ...k,
      mastered: localKanjiMastery.get(k.id) ?? k.mastered ?? false,
    })),
    kanjiVocabList: (cloudCourse.kanjiVocabList || []).map((v) => ({
      ...v,
      mastered: localKanjiVocabMastery.get(v.id) ?? v.mastered ?? false,
    })),
  };
}

export function saveJapaneseCourses(courses: JapaneseCourse[], email?: string | null, skipCloudSync = false): void {
  try {
    const targetEmail = (email !== undefined ? (email || '') : getCurrentUserEmail()).toLowerCase().trim();
    const hasAccess = canAccessJpd123(targetEmail);
    const userKey = getCoursesStorageKey(targetEmail);

    let toSave = courses;

    if (!hasAccess) {
      toSave = toSave.filter(
        (c) =>
          c &&
          c.id !== 'course-jpd123' &&
          c.code?.toLowerCase().replace(/\s+/g, '') !== 'jpd123'
      );
    }
    toSave = toSave.filter(c => !c.deletedAt && !getDeletedJapaneseCourseIds(targetEmail).includes(c.id));
    const encoded = JSON.stringify(toSave);
    if(localStorage.getItem(userKey) !== encoded) {localStorage.setItem(userKey,encoded);notifyDataChanged(userKey);}

    // Also sync to Cloud Firestore in background for this specific user
    if (!skipCloudSync && targetEmail) {
      for (const c of toSave) {
        syncJapaneseCourseToFirestore(c, targetEmail).catch(() => {});
      }
    }
  } catch (e) {
    console.error('Failed to save Japanese courses:', e);
  }
}

export function getJapaneseCourseById(id: string, email?: string | null): JapaneseCourse | null {
  const targetEmail = (email !== undefined ? (email || '') : getCurrentUserEmail()).toLowerCase().trim();
  const hasAccess = canAccessJpd123(targetEmail);

  if ((id === 'course-jpd123' || id.toLowerCase().includes('jpd123')) && !hasAccess) {
    return null;
  }

  const courses = getJapaneseCourses(targetEmail);
  return courses.find((c) => c.id === id) || null;
}

export function restoreDefaultJpd123Course(email?: string | null): JapaneseCourse[] {
  const targetEmail = (email !== undefined ? (email || '') : getCurrentUserEmail()).toLowerCase().trim();
  const current = getJapaneseCourses(targetEmail);
  const withoutJpd = current.filter(
    (c) => c && c.id !== 'course-jpd123' && c.code?.toLowerCase().replace(/\s+/g, '') !== 'jpd123'
  );
  const restoredCourse: JapaneseCourse = {
    ...getCleanDefaultJpdCourse(),
    updatedAt: new Date().toISOString(),
  };
  clearJapaneseCourseDeletion(restoredCourse.id,targetEmail);
  const next = [restoredCourse, ...withoutJpd];
  saveJapaneseCourses(next, targetEmail, true);
  if (targetEmail) {
    syncJapaneseCourseToFirestore(restoredCourse, targetEmail).catch(() => {});
  }
  return next;
}

export function saveJapaneseCourse(course: JapaneseCourse, email?: string | null): JapaneseCourse[] {
  const targetEmail = (email !== undefined ? (email || '') : getCurrentUserEmail()).toLowerCase().trim();

  const current = getJapaneseCourses(targetEmail);
  const idx = current.findIndex((c) => c.id === course.id);
  let updated: JapaneseCourse[];

  const formatted: JapaneseCourse = {
    ...course,
    updatedAt: new Date(Math.max(Date.now(), Date.parse(current[idx]?.updatedAt || '') + 1 || 0)).toISOString(),
    ...(course.id === 'course-jpd123' ? {
      deletedGrammarIds: JPD123_GRAMMAR_POINTS.filter(g=>!course.grammarPoints.some(x=>x.id===g.id)).map(g=>g.id),
    } : {}),
  };
  clearJapaneseCourseDeletion(course.id,targetEmail);

  if (idx >= 0) {
    updated = [...current];
    updated[idx] = formatted;
  } else {
    updated = [
      {
        ...formatted,
        createdAt: formatted.createdAt || new Date().toISOString(),
      },
      ...current,
    ];
  }

  // Always save to user's personalized local storage (allows students and admin to save their card mastery & progress!)
  saveJapaneseCourses(updated, targetEmail, true);

  // Sync to this user's personal cloud document in Firestore (preserves personal mastery across devices for this account)
  if (targetEmail) {
    syncJapaneseCourseToFirestore(formatted, targetEmail).catch(() => {});
  }

  return updated;
}

export function deleteJapaneseCourse(courseId: string, email?: string | null): JapaneseCourse[] {
  const targetEmail = (email !== undefined ? (email || '') : getCurrentUserEmail()).toLowerCase().trim();
  const current = getJapaneseCourses(targetEmail);
  const updated = current.filter((c) => c.id !== courseId);
  markJapaneseCourseDeleted(courseId,targetEmail);
  saveJapaneseCourses(updated, targetEmail, true);
  if (targetEmail) {
    deleteJapaneseCourseFromFirestore(courseId, targetEmail).catch(() => {});
  }
  return updated;
}

export function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}


function deletionKey(email?:string|null):string {return getCoursesStorageKey(email)+'_deleted';}
export function getDeletedJapaneseCourseIds(email?:string|null):string[] {
  try{return JSON.parse(localStorage.getItem(deletionKey(email)) || '[]');}catch{return [];}
}
function courseDeletionTimes(email?:string|null):Record<string,string> {
  try{return JSON.parse(localStorage.getItem(deletionKey(email)+'_at')||'{}');}catch{return {};}
}
function markJapaneseCourseDeleted(id:string,email?:string|null,at=new Date().toISOString()):void {
  const ids=getDeletedJapaneseCourseIds(email);if(!ids.includes(id))localStorage.setItem(deletionKey(email),JSON.stringify([...ids,id]));
  localStorage.setItem(deletionKey(email)+'_at',JSON.stringify({...courseDeletionTimes(email),[id]:at}));
}
function clearJapaneseCourseDeletion(id:string,email?:string|null):void {
  localStorage.setItem(deletionKey(email),JSON.stringify(getDeletedJapaneseCourseIds(email).filter(x=>x!==id)));
  const times=courseDeletionTimes(email);delete times[id];localStorage.setItem(deletionKey(email)+'_at',JSON.stringify(times));
}
// Both App and the course page use the same reconciliation instead of reseeding independently.
export function reconcileJapaneseCoursesFromCloud(incoming:JapaneseCourse[],email?:string|null):JapaneseCourse[] {
  const local=getJapaneseCourses(email);const byId=new Map(local.map(c=>[c.id,c]));const next:JapaneseCourse[]=[];
  for(const remote of incoming){
    if(remote.deletedAt){
      const restored=byId.get(remote.id);
      if(restored&&Date.parse(restored.updatedAt)>Date.parse(remote.deletedAt)){next.push(restored);continue;}
      markJapaneseCourseDeleted(remote.id,email,remote.deletedAt);continue;
    }
    if(getDeletedJapaneseCourseIds(email).includes(remote.id)){
      const deletionTime=Date.parse(courseDeletionTimes(email)[remote.id]||'');
      if(deletionTime&&Date.parse(remote.updatedAt)>deletionTime)clearJapaneseCourseDeletion(remote.id,email);
      else continue;
    }
    const cached=byId.get(remote.id);
    const newer=cached&&Date.parse(cached.updatedAt)>Date.parse(remote.updatedAt);
    next.push(newer?cached:remote);
    if(newer&&email)syncJapaneseCourseToFirestore(cached,email).catch(()=>{});
  }
  // A course not uploaded yet remains available while the first cloud snapshot is empty.
  for(const cached of local)if(!incoming.some(c=>c.id===cached.id)&&!getDeletedJapaneseCourseIds(email).includes(cached.id)){
    next.push(cached);if(email)syncJapaneseCourseToFirestore(cached,email).catch(()=>{});
  }
  saveJapaneseCourses(next,email,true);return getJapaneseCourses(email);
}
