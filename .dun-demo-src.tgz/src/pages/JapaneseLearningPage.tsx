import { subscribeStorageKeys } from '../utils/storageEvents';
import React, { useState, useEffect } from 'react';
import {
  FolderOpen,
  Plus,
  ArrowRight,
  BookOpen,
  Layers,
  FileText,
  Trash2,
  Edit3,
  Search,
  Sparkles,
  X,
  ShieldCheck,
  RotateCcw,
} from 'lucide-react';
import { JapaneseCourse } from '../types/japanese';
import {
  getJapaneseCourses,
  getCoursesStorageKey,
  reconcileJapaneseCoursesFromCloud,
  saveJapaneseCourse,
  deleteJapaneseCourse,
  isJapaneseAdmin,
  saveJapaneseCourses,
  canAccessJpd123,
  restoreDefaultJpd123Course,
  getCleanDefaultJpdCourse,
  ensureJpdCourseUpToDate,
} from '../utils/japaneseStorage';
import { subscribeJapaneseCourses, syncJapaneseCourseToFirestore } from '../lib/firebase';
import { JapaneseCourseDetail } from './JapaneseCourseDetail';
import { sound } from '../utils/audio';

interface Props {
  currentUser?: { email: string; name: string } | null;
  onBackToDashboard?: () => void;
}

export const JapaneseLearningPage: React.FC<Props> = ({ currentUser, onBackToDashboard }) => {
  const [courses, setCourses] = useState<JapaneseCourse[]>([]);
  const [selectedCourse, setSelectedCourse] = useState<JapaneseCourse | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Course Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState<JapaneseCourse | null>(null);
  const [courseToDelete, setCourseToDelete] = useState<JapaneseCourse | null>(null);

  const [formData, setFormData] = useState({
    code: '',
    title: '',
    description: '',
    level: 'N5' as JapaneseCourse['level'],
  });

  const isAdmin = isJapaneseAdmin(currentUser?.email);
  const hasJpdAccess = canAccessJpd123(currentUser?.email);

  useEffect(() => {
    const list = getJapaneseCourses(currentUser?.email);
    setCourses(list);
    // If admin or delegated user and there is 1 course (e.g. JPD 123), automatically open it for convenience
    if (hasJpdAccess && list.length === 1 && !selectedCourse) {
      setSelectedCourse(list[0]);
    } else if (!hasJpdAccess) {
      // For non-authorized user, if they had JPD 123 open previously, close it
      if (selectedCourse?.id === 'course-jpd123') {
        setSelectedCourse(null);
      }
    }

    // Subscribe to Firestore for real-time synchronization between phones, tablets, and computers FOR THIS USER
    const refresh = () => {
      const fresh=getJapaneseCourses(currentUser?.email);setCourses(fresh);
      setSelectedCourse(prev=>prev?fresh.find(c=>c.id===prev.id)||null:(hasJpdAccess&&fresh.length===1?fresh[0]:null));
    };
    const stopLocal=subscribeStorageKeys(key=>key===getCoursesStorageKey(currentUser?.email),refresh);
    const unSub = subscribeJapaneseCourses(currentUser?.email, cloud=>{
      if(Array.isArray(cloud)){reconcileJapaneseCoursesFromCloud(cloud,currentUser?.email);refresh();}
    });

    return () => {
      stopLocal(); if (unSub) unSub();
    };
  }, [currentUser?.email, isAdmin, hasJpdAccess]);

  const refreshCourses = () => {
    const list = getJapaneseCourses(currentUser?.email);
    setCourses(list);
    if (selectedCourse) {
      const updated = list.find((c) => c.id === selectedCourse.id);
      setSelectedCourse(updated || null);
    }
  };

  const handleOpenCourse = (course: JapaneseCourse) => {
    setSelectedCourse(course);
    sound.playClick();
  };

  const handleUpdateCourse = (updatedCourse: JapaneseCourse) => {
    const updatedList = saveJapaneseCourse(updatedCourse, currentUser?.email);
    setCourses(updatedList);
    setSelectedCourse(updatedCourse);
  };

  const openCreateModal = () => {
    setFormData({
      code: '',
      title: '',
      description: '',
      level: 'N5',
    });
    setEditingCourse(null);
    setIsModalOpen(true);
  };

  const openEditModal = (c: JapaneseCourse, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setFormData({
      code: c.code,
      title: c.title,
      description: c.description,
      level: c.level || 'N5',
    });
    setEditingCourse(c);
    setIsModalOpen(true);
  };

  const handleSaveCourse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.code.trim() || !formData.title.trim()) return;

    if (editingCourse) {
      const updated: JapaneseCourse = {
        ...editingCourse,
        code: formData.code.trim().toUpperCase(),
        title: formData.title.trim(),
        description: formData.description.trim(),
        level: formData.level,
        updatedAt: new Date().toISOString(),
      };
      saveJapaneseCourse(updated, currentUser?.email);
      if (selectedCourse?.id === updated.id) {
        setSelectedCourse(updated);
      }
    } else {
      const newCourse: JapaneseCourse = {
        id: `course-${Date.now()}`,
        code: formData.code.trim().toUpperCase(),
        title: formData.title.trim(),
        description: formData.description.trim() || `Khóa học ${formData.code.toUpperCase()}`,
        level: formData.level,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        lessons: [],
        kanjiList: [],
        grammarPoints: [],
        materials: [],
      };
      saveJapaneseCourse(newCourse, currentUser?.email);
      setSelectedCourse(newCourse);
    }

    refreshCourses();
    setIsModalOpen(false);
    setEditingCourse(null);
    sound.playClick();
  };

  const handleDeleteCourseConfirm = () => {
    if (!courseToDelete) return;
    const updated = deleteJapaneseCourse(courseToDelete.id, currentUser?.email);
    setCourses(updated);
    if (selectedCourse?.id === courseToDelete.id) {
      setSelectedCourse(null);
    }
    setCourseToDelete(null);
    sound.playClick();
  };

  // If a course is selected, show its detail view
  if (selectedCourse) {
    return (
      <div className="w-full max-w-[1680px] mx-auto px-3 sm:px-5 lg:px-6 py-4">
        <JapaneseCourseDetail
          course={selectedCourse}
          onBackToCourses={() => setSelectedCourse(null)}
          onUpdateCourse={handleUpdateCourse}
        />
      </div>
    );
  }

  const filteredCourses = courses.filter((c) => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      c.code.toLowerCase().includes(q) ||
      c.title.toLowerCase().includes(q) ||
      c.description.toLowerCase().includes(q)
    );
  });

  const courseGradients = [
    'from-orange-500 via-amber-500 to-yellow-500',
    'from-indigo-500 via-purple-500 to-pink-500',
    'from-emerald-500 via-teal-500 to-cyan-500',
    'from-blue-500 via-indigo-500 to-violet-500',
    'from-rose-500 via-pink-500 to-amber-500',
  ];

  const getCourseProgress = (c: JapaneseCourse) => {
    let total = 0;
    let mastered = 0;
    if (c.lessons) {
      c.lessons.forEach((l) => {
        if (l.cards) {
          total += l.cards.length;
          mastered += l.cards.filter((card) => card.mastered).length;
        }
      });
    }
    if (c.kanjiList) {
      total += c.kanjiList.length;
      mastered += c.kanjiList.filter((k) => k.mastered).length;
    }
    return total > 0 ? Math.round((mastered / total) * 100) : 0;
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-linear-to-br from-slate-900 via-indigo-950 to-slate-900 text-white shadow-xl relative overflow-hidden border border-slate-800">
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-bl from-orange-500/10 to-transparent rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-gradient-to-tr from-rose-500/10 to-transparent rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-black uppercase tracking-wider text-rose-400">
              <Sparkles className="w-4 h-4" />
              <span>Hệ thống Quản lý Khóa học Tiếng Nhật</span>
              {isAdmin ? (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold">
                  <ShieldCheck className="w-3 h-3" />
                  Admin
                </span>
              ) : null}
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
              Khóa Học Tiếng Nhật
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 font-medium leading-relaxed">
              Mỗi khóa học tổng hợp gồm 3 khu vực chính:{' '}
              <strong className="text-orange-400">1. Từ vựng</strong> (các bài học kèm Flashcard, Gõ, Trắc nghiệm),{' '}
              <strong className="text-rose-400">2. Chữ Hán</strong> (Kanji & âm Hán Việt), và{' '}
              <strong className="text-indigo-400">3. Ngữ pháp</strong> (cấu trúc ngữ pháp & ví dụ song ngữ).
            </p>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap">
            {isAdmin && (
              <button
                type="button"
                onClick={() => {
                  if (window.confirm('Khôi phục lại toàn bộ khóa học JPD123 gốc (Từ vựng Bài 4-7, Chữ Hán, Ngữ pháp, Tài liệu)?')) {
                    const restored = restoreDefaultJpd123Course(currentUser?.email);
                    setCourses(restored);
                    sound.playSuccess();
                  }
                }}
                className="px-4 py-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-black text-xs border border-white/20 flex items-center gap-2 cursor-pointer active:scale-95 shrink-0 transition-colors"
                title="Khôi phục lại dữ liệu JPD123 gốc nếu lỡ tay xóa"
              >
                <RotateCcw className="w-4 h-4 text-emerald-400" />
                <span>Khôi phục JPD123 gốc</span>
              </button>
            )}

            <button
              type="button"
              onClick={openCreateModal}
              className="px-5 py-3 rounded-2xl bg-linear-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-black text-xs sm:text-sm shadow-lg shadow-orange-500/30 flex items-center gap-2 cursor-pointer active:scale-95 shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>+ Tạo File Tổng / Khóa Học Mới</span>
            </button>
          </div>
        </div>
      </div>

      {/* Search & Actions Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-0.5">
          <span className="text-[11px] font-black text-slate-400 uppercase tracking-wider">
            DANH SÁCH KHÓA HỌC / FILE TỔNG
          </span>
          <h2 className="text-lg font-black text-slate-900 dark:text-white">
            Danh sách khóa học
          </h2>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Tìm theo mã, tên khóa học..."
            className="w-full pl-10 pr-3.5 py-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-orange-500 shadow-xs"
          />
        </div>
      </div>

      {/* Courses List / Grid */}
      {filteredCourses.length === 0 ? (
        <div className="text-center py-16 px-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
          <FolderOpen className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto" />
          <div className="space-y-1">
            <h3 className="text-base font-black text-slate-800 dark:text-slate-200">
              {searchQuery ? 'Không tìm thấy khóa học phù hợp' : 'Chưa có khóa học nào'}
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 max-w-sm mx-auto">
              {searchQuery
                ? 'Thử tìm kiếm với từ khóa khác.'
                : 'Danh sách khóa học của bạn đang trống trơn. Bấm nút tạo khóa học mới để bắt đầu.'}
            </p>
          </div>
          <div className="flex items-center justify-center gap-3 flex-wrap pt-2">
            {isAdmin && (
              <button
                type="button"
                onClick={() => {
                  const restored = restoreDefaultJpd123Course(currentUser?.email);
                  setCourses(restored);
                  sound.playSuccess();
                }}
                className="px-6 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs inline-flex items-center gap-2 cursor-pointer shadow-md shadow-indigo-600/30 active:scale-95"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Khôi phục lại Khóa học JPD123 gốc</span>
              </button>
            )}
            <button
              type="button"
              onClick={openCreateModal}
              className="px-6 py-2.5 rounded-2xl bg-orange-500 hover:bg-orange-600 text-white font-black text-xs inline-flex items-center gap-2 cursor-pointer shadow-md shadow-orange-500/30 active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>Tạo khóa học mới</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredCourses.map((c, idx) => {
            const progress = getCourseProgress(c);
            const gradient = courseGradients[idx % courseGradients.length];
            const level = c.level || 'N5';

            return (
              <div
                key={c.id}
                onClick={() => handleOpenCourse(c)}
                className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-orange-400 dark:hover:border-orange-500 shadow-xs hover:shadow-xl transition-all cursor-pointer flex flex-col justify-between group overflow-hidden"
              >
                {/* Top Color Bar */}
                <div className={`h-2 bg-gradient-to-r ${gradient}`} />

                <div className="p-6 space-y-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-orange-500 to-amber-600 text-white flex items-center justify-center font-black text-lg shadow-md shadow-orange-500/20 shrink-0">
                        🇯🇵
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="px-2.5 py-0.5 rounded-lg bg-orange-100 dark:bg-orange-950/80 text-orange-600 dark:text-orange-400 font-extrabold text-[11px]">
                            {c.code || 'JPD 123'}
                          </span>
                          <span className="px-2 py-0.5 rounded-lg bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 font-black text-[10px] border border-rose-200 dark:border-rose-800/50">
                            {level}
                          </span>
                        </div>
                        <h3 className="text-base font-black text-slate-900 dark:text-white mt-1 group-hover:text-orange-500 transition-colors">
                          {c.title}
                        </h3>
                      </div>
                    </div>

                    {(!c.id.includes('jpd123') && c.code?.toLowerCase().replace(/\s+/g, '') !== 'jpd123') || isAdmin ? (
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          type="button"
                          onClick={(e) => openEditModal(c, e)}
                          className="p-1.5 rounded-xl text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                          title="Sửa thông tin"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setCourseToDelete(c);
                          }}
                          className="p-1.5 rounded-xl text-rose-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/60 transition-colors cursor-pointer"
                          title="Xóa khóa học"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ) : null}
                  </div>

                  <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                    {c.description || 'Khóa học tiếng Nhật tổng hợp'}
                  </p>

                  {/* Progress Bar */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-[10px] font-bold">
                      <span className="text-slate-400 dark:text-slate-500">Tiến độ ghi nhớ</span>
                      <span className={progress >= 70 ? 'text-emerald-500 dark:text-emerald-400' : progress >= 40 ? 'text-amber-500 dark:text-amber-400' : 'text-slate-500 dark:text-slate-400'}>
                        {progress}%
                      </span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          progress >= 70
                            ? 'bg-gradient-to-r from-emerald-500 to-teal-400'
                            : progress >= 40
                            ? 'bg-gradient-to-r from-amber-500 to-orange-400'
                            : 'bg-gradient-to-r from-orange-500 to-rose-400'
                        }`}
                        style={{ width: `${Math.max(progress, 3)}%` }}
                      />
                    </div>
                  </div>

                  {/* 3 Modules Status Pills */}
                  <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                    <div className="flex items-center gap-1.5 p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                      <BookOpen className="w-3.5 h-3.5 text-sky-500 shrink-0" />
                      <span className="font-bold text-slate-700 dark:text-slate-300 truncate">
                        {c.lessons?.length || 0} bài từ vựng
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                      <span className="text-xs font-serif font-black text-rose-500 shrink-0">🈲</span>
                      <span className="font-bold text-slate-700 dark:text-slate-300 truncate">
                        {c.kanjiList?.length || 0} chữ Hán
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                      <FileText className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                      <span className="font-bold text-slate-700 dark:text-slate-300 truncate">
                        {c.grammarPoints?.length || 0} ngữ pháp
                      </span>
                    </div>
                  </div>
                </div>

                {/* Enter Button */}
                <div className="flex items-center justify-between px-6 py-3 border-t border-slate-100 dark:border-slate-800 text-xs font-bold text-orange-600 dark:text-orange-400 group-hover:translate-x-1 transition-transform">
                  <span>Vào học phần {c.code}</span>
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            );
          })}

          {/* Add New Course Card */}
          <div
            onClick={openCreateModal}
            className="rounded-3xl bg-white/50 dark:bg-slate-900/50 border-2 border-dashed border-slate-200 dark:border-slate-800 hover:border-orange-400 dark:hover:border-orange-500/50 shadow-xs hover:shadow-xl transition-all cursor-pointer flex flex-col items-center justify-center min-h-[300px] group p-6 text-center space-y-3"
          >
            <div className="w-14 h-14 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500 group-hover:text-orange-500 group-hover:bg-orange-50 dark:group-hover:bg-orange-950/30 flex items-center justify-center mx-auto transition-colors">
              <Plus className="w-7 h-7" />
            </div>
            <div>
              <p className="text-sm font-black text-slate-700 dark:text-slate-300 group-hover:text-orange-500 transition-colors">
                Tạo khóa học mới
              </p>
              <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
                Bấm để thêm File Tổng / Khóa học
              </p>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: CREATE / EDIT COURSE */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-orange-100 dark:bg-orange-950 text-orange-600 flex items-center justify-center font-black">
                  🇯🇵
                </div>
                <h3 className="text-base font-black text-slate-900 dark:text-white">
                  {editingCourse ? 'Chỉnh sửa Khóa học' : 'Tạo File Tổng / Khóa học Mới'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveCourse} className="space-y-3.5">
              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-1 space-y-1">
                  <label className="text-xs font-black text-slate-700 dark:text-slate-300">
                    Mã khóa *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.code}
                    onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                    placeholder="VD: JPD 123"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-bold uppercase focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>
                <div className="col-span-2 space-y-1">
                  <label className="text-xs font-black text-slate-700 dark:text-slate-300">
                    Tên file / Khóa học *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="VD: Tiếng Nhật JPD 123"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-black text-slate-700 dark:text-slate-300">
                  Mô tả khóa học
                </label>
                <textarea
                  rows={2}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="VD: Khóa học tiếng Nhật JPD123 tổng hợp - Từ vựng, Chữ Hán, Ngữ pháp, Tài liệu"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs focus:outline-none focus:ring-2 focus:ring-orange-500 resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-600 dark:text-slate-300"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 text-white text-xs font-black shadow-md shadow-orange-500/30 cursor-pointer"
                >
                  Lưu khóa học
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: DELETE CONFIRMATION */}
      {courseToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-100 dark:bg-rose-950 text-rose-600 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-base font-black text-slate-900 dark:text-white">
                  Xóa khóa học {courseToDelete.code}?
                </h4>
                <p className="text-xs text-slate-500">
                  Tất cả từ vựng, chữ Hán, ngữ pháp và tài liệu trong mục này sẽ bị xóa.
                </p>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setCourseToDelete(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-600 dark:text-slate-300 cursor-pointer"
              >
                Hủy
              </button>
              <button
                type="button"
                onClick={handleDeleteCourseConfirm}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black cursor-pointer"
              >
                Xóa ngay
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
